# MySt Quick Reference


## Code Blocks

```{code-block} python
:linenos:
:caption: text for caption
:emphasize-lines: 2

print("Hello, ...")
print("World!")
print("(with highlights!!)")
```