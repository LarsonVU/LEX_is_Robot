"""Robogen Lite Modules."""
