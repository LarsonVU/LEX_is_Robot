"""EA Framework."""
