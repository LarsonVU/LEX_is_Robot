"""Test suite for the ariel package."""
